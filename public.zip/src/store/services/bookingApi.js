import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { env } from "./../../env";
export const bookingApi = createApi({
    reducerPath : "bookingsApi",
    baseQuery: fetchBaseQuery({ baseUrl: env.apiUrl }),
    tagTypes: ["Bookings"],
    endpoints: (builder) => ({
        getBookings: builder.query({
            query: () => "/bookings"
        }),

        getMyBookings: builder.query({
            query: () => "/bookings/my"
        }),

        getBooking: builder.query({
            query: (id) => `/bookings/${id}`
        }),

        createBooking: builder.mutation({
            query: (booking) => ({
                url: "/bookings",
                method: "POST",
                body: booking
            })
        }),

        updateBooking: builder.mutation({
            query: (booking) => ({
                url: "/bookings",
                method: "PUT",
                body: booking
            })
        }),

        deleteBooking: builder.mutation({
            query: (id) => ({
                url: `/bookings/${id}`,
                method: "DELETE"
            })
        })
    })
});

export const {
    useGetBookingsQuery,
    useGetMyBookingsQuery,
    useGetBookingQuery,
    useCreateBookingMutation,
    useUpdateBookingMutation,
    useDeleteBookingMutation
} = bookingApi;