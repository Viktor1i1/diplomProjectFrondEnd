import Baner from "../../components/baner/Baner";
import ArtistHome from "../../components/ArtistHome/ArtistHome";


function Home({city}) {
    return(
        <div>
            <div>
                <Baner city={city}/>
            </div>
            <div>
                <ArtistHome/>
            </div>
        </div>
    )
}

export default Home;